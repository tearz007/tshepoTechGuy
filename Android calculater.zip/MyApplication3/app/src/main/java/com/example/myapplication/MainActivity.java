package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button button;
    private RadioButton addBtn;
    private RadioButton subBtn;
    private RadioButton multBtn;
    private TextView tview;
            String oparetor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        button=(Button) findViewById(R.id.nextBtn) ;
        addBtn =(RadioButton)findViewById(R.id.addBtn);
        subBtn =(RadioButton) findViewById(R.id.subBtn);
        multBtn =(RadioButton) findViewById(R.id.multiBtn);
        tview  =(TextView)findViewById(R.id.tView);

        Toast.makeText(getApplication(),"on open",Toast.LENGTH_LONG).show();

         tview.setText("  Tearz Love");



        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                oparetor="1";
                Toast.makeText(getApplication(),"add clicked",Toast.LENGTH_SHORT).show();
            }
        });

        subBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                oparetor="2";
                Toast.makeText(getApplication(),"subtraction clicked",Toast.LENGTH_SHORT).show();
            }
        });

        multBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                oparetor="3";
                Toast.makeText(getApplication(),"multiblication clicked",Toast.LENGTH_SHORT).show();
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplication(),secondActivity.class);
                intent.putExtra("com.example.myapplication.tearz",oparetor);
                startActivity(intent);
                Toast.makeText(getApplication(),"on btn pressed",Toast.LENGTH_LONG).show();

            }
        });

    }
}
