package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class secondActivity extends AppCompatActivity {

    EditText num1;
    EditText num2;
    Button calbtn;
    String oparetor;
    int firstNum=0;
    int secondNum=0;
    TextView viewRess;
    TextView opview;

    int op;
    int result=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

         oparetor=getIntent().getExtras().getString("com.example.myapplication.tearz");
        Toast.makeText(getApplication(),"second page",Toast.LENGTH_SHORT).show();
        Toast.makeText(getApplication(),oparetor,Toast.LENGTH_LONG).show();

        num1= (EditText) findViewById(R.id.editTextNum1);
        num2= (EditText) findViewById(R.id.editTextNum2);
        calbtn = (Button) findViewById(R.id.calbutton);
        viewRess = (TextView) findViewById(R.id.viewRu);
        opview = (TextView) findViewById(R.id.opView2);


        op=Integer.parseInt(oparetor.toString());

        if (op ==1){

        opview.setText("+");
        }
        if (op == 2){

            opview.setText("-");
        }
        if (op == 3){

            opview.setText("*");

        }





         calbtn.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                // Toast.makeText(getApplication(),"on cal btn",Toast.LENGTH_SHORT).show();
                  firstNum = Integer.parseInt( num1.getText().toString());
                  secondNum = Integer.parseInt( num2.getText().toString());

        if (op ==1){

         result = firstNum + secondNum;
            Toast.makeText(getApplication(),oparetor,Toast.LENGTH_LONG).show();

        }
        if (op == 2){

            result = firstNum - secondNum;
        }
        if (op == 3){

            result = firstNum * secondNum;
        }

                 viewRess.setText(result+" ");


             }

         });





    }

}
