#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QFileDialog>
#include<QUrl>
#include<QDir>
#include<QFileInfo>
#include<QFile>
#include<QMessageBox>
#include<QTextStream>



MainWindow::MainWindow(QWidget *parent) :
   QMainWindow(parent),
   ui(new Ui::MainWindow)
{
   ui->setupUi(this);
   player= new QMediaPlayer;
  // video =new QVideoWidget(this);
 //  player->setVideoOutput(video);
 //  this->setCentralWidget(video);

//video->setMouseTracking(true);
connect(player,&QMediaPlayer::durationChanged,ui->slider,&QSlider::setMaximum);
connect(player,&QMediaPlayer::positionChanged,ui->slider,&QSlider::setValue);
connect(ui->slider,&QSlider::sliderMoved,player,&QMediaPlayer::setPosition);

//connect(ui->slider,&QSlider::valueChanged,ui->labelStsrt,&QLabel::setText(QString));

/***********************************************/
   QFile file("out.txt");
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
            return;

        while (!file.atEnd()) {
            QString sName = file.readLine();
            list_Read.append(sName.trimmed());

        }

        for (int i = 0; i < list_Read.size(); ++i) {
           ui->listWidget->addItem(list_Read.at(i));
        }
}
MainWindow::~MainWindow()
{
   delete ui;
}
void MainWindow::on_actionopen_triggered()
{
    QString name = QFileDialog::getOpenFileName(this,"open a file"," "," videoFile (* . *)");
    player->setMedia(QUrl::fromLocalFile(name));
    ui->listWidget->addItem(name);

    list_Write.append(name);
}
void MainWindow::on_actionPlay_triggered()
{
    player->play();
}

void MainWindow::on_actionPouse_triggered()
{
    player->pause();
}

void MainWindow::on_actionStop_triggered()
{
    player->stop();
}

void MainWindow::on_listWidget_itemClicked(QListWidgetItem *item)
{
   nameP = item->text();

   for (int i = 0; i < ui->listWidget->count(); i++) {

       if (nameP == ui->listWidget->item(i)->text()) {

           index=i;
      }
   }
}

void MainWindow::on_listWidget_itemDoubleClicked(QListWidgetItem *item)
{
     listName=item->text();
     player->setMedia(QUrl::fromLocalFile(listName));
     ui->label->clear();
     ui->label->setText(listName);
qDebug()<<"its the same";
}



void MainWindow::on_next_clicked()
{
    int pointer=0;


    qDebug()<<QString("first index %1").arg(index);

    if (ui->listWidget->count()>1 && index<=ui->listWidget->count()) {

        if (index+1<ui->listWidget->count()) {
          pointer=index+1;

        }
      if ((index+1)>ui->listWidget->count()) {

            index=-1;
             //pointer=index;
        }

      QString name=ui->listWidget->item(pointer)->text();
      player->setMedia(QUrl::fromLocalFile(name));
      ui->label->clear();
      ui->label->setText(name);
      player->play();
 qDebug()<<QString("at position %1").arg(pointer);
    }
     index=index+1;



}


void MainWindow::on_playB_clicked()
{
    player->setMedia(QUrl::fromLocalFile(listName));
    ui->label->clear();
    ui->label->setText(listName);
    player->play();

}


void MainWindow::on_pauseB_clicked()
{
    player->pause();
}

void MainWindow::on_prev_clicked()
{
    int pointer=0;



    if (ui->listWidget->count()>1) {

        if (index>0) {
          pointer=index-1;

        }
        if (index=0) {
            pointer=0;
            index++;
        }

      QString name=ui->listWidget->item(pointer)->text();
      player->setMedia(QUrl::fromLocalFile(name));
      ui->label->clear();
      ui->label->setText(name);
      player->play();
      qDebug()<<"ass";
    }
     index-=1;


}

void MainWindow::on_actionaddplayList_triggered()
{
      QMessageBox msg;
      msg.setText("Playlist saved");
      msg.exec();

      QFile file("out.txt");
      if (!file.open(QIODevice::WriteOnly | QIODevice::Text))
          return;

      QTextStream out(&file);


    /**************************************/
    for (int i = 0; i <list_Write.size(); ++i) {
         out <<QString("%1 ").arg(list_Write.at(i))<<endl;
    }
}

void MainWindow::on_actionclear_list_triggered()
{
    ui->listWidget->clear();
}
/*
void MainWindow::on_next_clicked()
{
    int pointer=0;
index=index;
    qDebug()<<QString("first index %1").arg(index);

    if (ui->listWidget->count()>1) {

        if ((index+1)<ui->listWidget->count()) {

            pointer=index+1;

        }

        if ((index+1)>ui->listWidget->count()) {
           pointer=0;

        }

      QString name=ui->listWidget->item(pointer)->text();
      player->setMedia(QUrl::fromLocalFile(name));
      ui->label->clear();
      ui->label->setText(name);
      player->play();
      qDebug()<<QString("at position %1").arg(pointer);
    }


        index=index+1;



}
*/

void MainWindow::on_actionShow_triggered()
{
    ui->listWidget->show();
}

void MainWindow::on_actionHide_triggered()
{
    ui->listWidget->hide();
}
