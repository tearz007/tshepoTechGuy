#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include<QMediaPlayer>
#include<QListWidget>
#include<QStringList>
#include<QVideoWidget>


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
     QMediaPlayer *player;
     QVideoWidget *video;
     QString nameP;
     QString listName;
     int index;
       QStringList list_Write;
       QStringList list_Read;
       int total=index+1;

private slots:


     void on_actionopen_triggered();

     void on_actionPlay_triggered();

     void on_actionPouse_triggered();

     void on_actionStop_triggered();

     void on_listWidget_itemClicked(QListWidgetItem *item);

     void on_listWidget_itemDoubleClicked(QListWidgetItem *item);

     void on_next_clicked();

     void on_playB_clicked();

     void on_pauseB_clicked();

     void on_prev_clicked();

     void on_actionaddplayList_triggered();

     void on_actionclear_list_triggered();

     void on_actionShow_triggered();

     void on_actionHide_triggered();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
