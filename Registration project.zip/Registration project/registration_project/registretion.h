#ifndef REGISTRETION_H
#define REGISTRETION_H

#include"mainwindow.h"
#include <QDialog>
#include<QFile>
#include<QStringList>
#include<QTextStream>
#include<QMessageBox>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>


namespace Ui {
class Registretion;
}

class Registretion : public QDialog
{
    Q_OBJECT

public:
    explicit Registretion(QWidget *parent = 0);
    ~Registretion();
    QString name;
    QString surname;
    QString address;
    QString email;
    QString number;
    QSqlDatabase dp;






private slots:
    void on_backButton_clicked();

    void on_registorButton_clicked();

private:
    Ui::Registretion *ui;

};

#endif // REGISTRETION_H
