#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QTextStream>
#include<QMessageBox>
#include<QStringList>
#include<QDebug>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_exitButton_clicked()
{
    close();
}

void MainWindow::on_loginButton_clicked()
{



    QSqlDatabase  dp = QSqlDatabase::addDatabase("QMYSQL");

    dp.setHostName("127.0.0.1");
    dp.setUserName("root");
    dp.setPassword("");
    dp.setDatabaseName("ragistration");

    if (dp.open()) {

        qDebug()<<"connected first";
    } else {
         qDebug()<<"Not connected";
    }

    QSqlQuery myquery;
    myquery.prepare("SELECT emailAddress, password"
                   " FROM register"
                   " WHERE emailAddress = ? ");

    myquery.addBindValue(ui->lineEditName->text());
    myquery.exec();

    QString dpEmail;
    QString dppassword;


    if (myquery.size()>0) {

        while (myquery.next()) {

        dpEmail=myquery.value("emailAddress").toString().toUtf8().constData();
        dppassword=myquery.value("password").toString().toUtf8().constData();

        qDebug()<<dpEmail<<"  "<<dppassword;

        }
    }else {
       QMessageBox::information(this,"login","no rows in the database");
    }

    if (dppassword==ui->lineEditPassword->text()) {

         QMessageBox::information(this,"login","you have now logged in");

    } else {

        QMessageBox::warning(this,"login","incorrect user name or password");
    }


}




void MainWindow::on_createAccnt_clicked()
{

     hide();
   Registretion *regist = new Registretion(this);
     regist->show();
}





/*   name=ui->lineEditName->text();
   pass=ui->lineEditPassword->text();

    QFile file(name+".txt");
   if (!file.open(QIODevice::WriteOnly | QIODevice::Text))
       return;

   QTextStream out(&file);
      out <<pass;


     QMessageBox msg;
     msg.setText("registed");
     msg.exec();*/



/*  for (int i = 0; i <2; ++i) {
    qDebug()<<name+" ";
    qDebug()<<surname+" ";
    qDebug()<<address+" ";
    qDebug()<<email+" ";
    qDebug()<<number+" ";
    qDebug()<<password+" ";

  }
*/


/*  QFile file("out.txt");
  if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
      return;

  QTextStream in(&file);
  while (!in.atEnd()) {
       line = in.readLine();
    }

  QStringList A=line.split("-");

  QString name = A[0];
  QString surname =A[1];
  QString address = A[2];
  QString email = A[3];
  QString number = A[4];
  QString password =A[5];

  for (int i = 0; i <1; ++i) {

      qDebug()<<name;
      qDebug()<<surname+" ";
      qDebug()<<address+" ";
      qDebug()<<email+" ";
      qDebug()<<number+" ";
      qDebug()<<password+" "<<"\n";

    }

QString name=ui->lineEditName->text();
QString pass=ui->lineEditPassword->text();

  QFile file(name+".txt");
 if (!file.open(QIODevice::WriteOnly | QIODevice::Text))
     return;

 QTextStream out(&file);
    out <<pass;


   QMessageBox msg;
   msg.setText("registed");
   msg.exec();
*/








