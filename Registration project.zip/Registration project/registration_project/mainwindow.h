#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include<QFile>
#include"registretion.h"
#include <QtSql/QtSql>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    QString nameL;
    QString surnameL;
    QString addressL;
    QString emailL;
    QString numberL;
    QString passwordL;

    QString   user_email;
    QString user_password;

   QString line;


private slots:
    void on_exitButton_clicked();

    void on_loginButton_clicked();

    void on_createAccnt_clicked();

private:
    Ui::MainWindow *ui;



};

#endif // MAINWINDOW_H
