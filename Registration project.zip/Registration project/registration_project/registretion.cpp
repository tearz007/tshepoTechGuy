#include "registretion.h"
#include "ui_registretion.h"
#include <QDebug>


Registretion::Registretion(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Registretion)
{
    ui->setupUi(this);

}

Registretion::~Registretion()
{
    delete ui;
}

void Registretion::on_backButton_clicked()
{
    hide();
   MainWindow *win=new MainWindow();
   win->show();
}

void Registretion::on_registorButton_clicked()
{

    if (ui->passwordR->text()==ui->confirmpassR->text()) {

        QFile file("out.txt");
        if (!file.open(QIODevice::Append | QIODevice::Text))
            return;

        QTextStream out(&file);
        out <<ui->nameR->text()<<"-"<<ui->surnameR->text()<<"-"<<ui->addressR->text()<<"-"<<ui->emailR->text()<<"-"<<ui->calNumR->text()
        <<"-"<<ui->passwordR->text()<< "\n";




        QSqlDatabase  dp = QSqlDatabase::addDatabase("QMYSQL");
        dp.setHostName("127.0.0.1");
        dp.setUserName("root");
        dp.setPassword("");
        dp.setDatabaseName("ragistration");

        if (dp.open()) {

            qDebug()<<"connected first";
        } else {
             qDebug()<<"Not connected";
        }

         QSqlQuery myquery;


         myquery.prepare("INSERT INTO register"
                         " values(?,?,?,?, ?,?)");
         myquery.addBindValue(ui->nameR->text());
         myquery.addBindValue(ui->surnameR->text());
         myquery.addBindValue(ui->addressR->text());
         myquery.addBindValue(ui->emailR->text());
         myquery.addBindValue(ui->calNumR->text());
         myquery.addBindValue(ui->passwordR->text());

         myquery.exec();

         dp.close();
          QMessageBox::information(this,"Login","Registered");
         hide();
         MainWindow *win=new MainWindow();
         win->show();


    } else {

         QMessageBox::information(this,"ragistration"," password doesnt match ");
    }



}
