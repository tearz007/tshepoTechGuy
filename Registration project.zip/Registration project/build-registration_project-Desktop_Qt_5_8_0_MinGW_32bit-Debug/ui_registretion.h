/********************************************************************************
** Form generated from reading UI file 'registretion.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REGISTRETION_H
#define UI_REGISTRETION_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_Registretion
{
public:
    QVBoxLayout *verticalLayout;
    QLabel *label_2;
    QFormLayout *formLayout;
    QLabel *label;
    QLineEdit *nameR;
    QLabel *label_3;
    QLineEdit *surnameR;
    QLabel *label_4;
    QLineEdit *addressR;
    QLabel *label_5;
    QLineEdit *emailR;
    QLabel *label_6;
    QLineEdit *calNumR;
    QLabel *label_7;
    QLabel *label_8;
    QLineEdit *passwordR;
    QLineEdit *confirmpassR;
    QHBoxLayout *horizontalLayout;
    QPushButton *backButton;
    QPushButton *registorButton;

    void setupUi(QDialog *Registretion)
    {
        if (Registretion->objectName().isEmpty())
            Registretion->setObjectName(QStringLiteral("Registretion"));
        Registretion->resize(330, 468);
        verticalLayout = new QVBoxLayout(Registretion);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        label_2 = new QLabel(Registretion);
        label_2->setObjectName(QStringLiteral("label_2"));
        QFont font;
        font.setPointSize(14);
        font.setBold(true);
        font.setItalic(true);
        font.setWeight(75);
        label_2->setFont(font);

        verticalLayout->addWidget(label_2);

        formLayout = new QFormLayout();
        formLayout->setObjectName(QStringLiteral("formLayout"));
        formLayout->setHorizontalSpacing(5);
        formLayout->setVerticalSpacing(14);
        formLayout->setContentsMargins(5, -1, -1, 114);
        label = new QLabel(Registretion);
        label->setObjectName(QStringLiteral("label"));
        label->setLineWidth(10);

        formLayout->setWidget(0, QFormLayout::LabelRole, label);

        nameR = new QLineEdit(Registretion);
        nameR->setObjectName(QStringLiteral("nameR"));

        formLayout->setWidget(0, QFormLayout::FieldRole, nameR);

        label_3 = new QLabel(Registretion);
        label_3->setObjectName(QStringLiteral("label_3"));

        formLayout->setWidget(1, QFormLayout::LabelRole, label_3);

        surnameR = new QLineEdit(Registretion);
        surnameR->setObjectName(QStringLiteral("surnameR"));

        formLayout->setWidget(1, QFormLayout::FieldRole, surnameR);

        label_4 = new QLabel(Registretion);
        label_4->setObjectName(QStringLiteral("label_4"));

        formLayout->setWidget(2, QFormLayout::LabelRole, label_4);

        addressR = new QLineEdit(Registretion);
        addressR->setObjectName(QStringLiteral("addressR"));

        formLayout->setWidget(2, QFormLayout::FieldRole, addressR);

        label_5 = new QLabel(Registretion);
        label_5->setObjectName(QStringLiteral("label_5"));

        formLayout->setWidget(3, QFormLayout::LabelRole, label_5);

        emailR = new QLineEdit(Registretion);
        emailR->setObjectName(QStringLiteral("emailR"));

        formLayout->setWidget(3, QFormLayout::FieldRole, emailR);

        label_6 = new QLabel(Registretion);
        label_6->setObjectName(QStringLiteral("label_6"));

        formLayout->setWidget(4, QFormLayout::LabelRole, label_6);

        calNumR = new QLineEdit(Registretion);
        calNumR->setObjectName(QStringLiteral("calNumR"));

        formLayout->setWidget(4, QFormLayout::FieldRole, calNumR);

        label_7 = new QLabel(Registretion);
        label_7->setObjectName(QStringLiteral("label_7"));

        formLayout->setWidget(5, QFormLayout::LabelRole, label_7);

        label_8 = new QLabel(Registretion);
        label_8->setObjectName(QStringLiteral("label_8"));

        formLayout->setWidget(6, QFormLayout::LabelRole, label_8);

        passwordR = new QLineEdit(Registretion);
        passwordR->setObjectName(QStringLiteral("passwordR"));
        passwordR->setEchoMode(QLineEdit::Password);

        formLayout->setWidget(5, QFormLayout::FieldRole, passwordR);

        confirmpassR = new QLineEdit(Registretion);
        confirmpassR->setObjectName(QStringLiteral("confirmpassR"));
        confirmpassR->setEchoMode(QLineEdit::Password);

        formLayout->setWidget(6, QFormLayout::FieldRole, confirmpassR);


        verticalLayout->addLayout(formLayout);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        backButton = new QPushButton(Registretion);
        backButton->setObjectName(QStringLiteral("backButton"));

        horizontalLayout->addWidget(backButton);

        registorButton = new QPushButton(Registretion);
        registorButton->setObjectName(QStringLiteral("registorButton"));

        horizontalLayout->addWidget(registorButton);


        verticalLayout->addLayout(horizontalLayout);


        retranslateUi(Registretion);

        QMetaObject::connectSlotsByName(Registretion);
    } // setupUi

    void retranslateUi(QDialog *Registretion)
    {
        Registretion->setWindowTitle(QApplication::translate("Registretion", "Dialog", Q_NULLPTR));
        label_2->setText(QApplication::translate("Registretion", "Enter details to register", Q_NULLPTR));
        label->setText(QApplication::translate("Registretion", "  Name    ", Q_NULLPTR));
        label_3->setText(QApplication::translate("Registretion", " Surname", Q_NULLPTR));
        label_4->setText(QApplication::translate("Registretion", "Address", Q_NULLPTR));
        label_5->setText(QApplication::translate("Registretion", "Email Addres", Q_NULLPTR));
        label_6->setText(QApplication::translate("Registretion", "Call number", Q_NULLPTR));
        label_7->setText(QApplication::translate("Registretion", "Password", Q_NULLPTR));
        label_8->setText(QApplication::translate("Registretion", "Confirm ", Q_NULLPTR));
        backButton->setText(QApplication::translate("Registretion", "Back", Q_NULLPTR));
        registorButton->setText(QApplication::translate("Registretion", "Registor", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Registretion: public Ui_Registretion {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REGISTRETION_H
